library(readr)

netflix_data <- read_csv("C:\\Users\\ifeol\\Downloads\\netflix_data.csv")
str(netflix_data)

# Perform data cleaning
clean_data <- na.omit(netflix_data)

# Data visualization
library(ggplot2)

# Create a bar chart for top genres
ggplot(netflix_data, aes(x = listed_in)) +
  geom_bar() +
  labs(x = "Genres", y = "Count", title = "Top Genres")


# Convert 'rating' column to character
netflix_data$rating <- as.character(netflix_data$rating)

# Create a histogram for ratings
ggplot(netflix_data, aes(x = rating)) +
  geom_histogram(binwidth = 0.5, fill = "skyblue", color = "black") +
  labs(x = "Rating", y = "Count", title = "Distribution of Ratings")